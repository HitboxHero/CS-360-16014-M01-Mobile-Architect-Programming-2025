package com.alex.inventori.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {

    // This method adds a new user to the database.
    @Insert
    void insert(User user);

    // This method finds a user based on their username.
    // The ":username" part is a placeholder for the variable passed into the method.
    @Query("SELECT * FROM users WHERE username = :username")
    User getUserByUsername(String username);
}