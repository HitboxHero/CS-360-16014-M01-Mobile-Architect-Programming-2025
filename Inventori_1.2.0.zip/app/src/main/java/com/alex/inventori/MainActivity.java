package com.alex.inventori;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.alex.inventori.database.AppDatabase;
import com.alex.inventori.database.User;
import com.alex.inventori.database.UserDao;

public class MainActivity extends AppCompatActivity {

    // Member variables for UI elements and database access
    private EditText usernameEditText, passwordEditText;
    private Button loginButton, signupButton;
    private AppDatabase db;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link the variables to the UI components from the XML layout
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginButton = findViewById(R.id.login_button);
        signupButton = findViewById(R.id.signup_button);

        // Get the single instance of the database and the User DAO
        db = AppDatabase.getDatabase(this);
        userDao = db.userDao();

        // Set up the click listener for the Login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password from the text fields
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Check for empty fields first to prevent blank logins
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
                    return; // Stop here if fields are empty
                }

                // Run database operation on a new thread because it's slow
                new Thread(() -> {
                    // Look for the user in the database
                    User user = userDao.getUserByUsername(username);

                    // Check if the user exists and the password is correct
                    if (user != null && user.passwordHash.equals(password)) {
                        // Switch back to the main thread to show a toast and start the next activity
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                            // Start the inventory screen
                            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                            startActivity(intent);
                            finish(); // Close this activity so the user can't go back with the back button
                        });
                    } else {
                        // User not found or password was wrong, so show an error
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                        });
                    }
                }).start();
            }
        });

        // Set up the click listener for the Sign Up button
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Check for empty fields
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Run database operation on a new thread
                new Thread(() -> {
                    // Check if the username is already taken
                    if (userDao.getUserByUsername(username) != null) {
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Username already taken.", Toast.LENGTH_SHORT).show();
                        });
                    } else {
                        // If username is available, create and save the new user
                        User newUser = new User();
                        newUser.username = username;
                        newUser.passwordHash = password; // Remember: this should be a real hash in a real app!
                        userDao.insert(newUser);

                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                        });
                    }
                }).start();
            }
        });
    }
}