package com.alex.inventori.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// This annotation marks this class as a database entity (a table)
// and names the table "inventory_items".
@Entity(tableName = "inventory_items")
public class InventoryItem {

    // This is the unique ID for each inventory item.
    // The "autoGenerate = true" part means Room will automatically give it a new number.
    @PrimaryKey(autoGenerate = true)
    public int id;

    // These are the columns in your database table.
    // They will store the item's name and the quantity.
    public String itemName;
    public int quantity;


}