// OnItemClickListener.java
package com.alex.inventori;

import com.alex.inventori.database.InventoryItem;

/**
 * An interface to handle button clicks on the items displayed in the RecyclerView.
 */
public interface OnItemClickListener {
    void onPlusClick(InventoryItem item);
    void onMinusClick(InventoryItem item);
}