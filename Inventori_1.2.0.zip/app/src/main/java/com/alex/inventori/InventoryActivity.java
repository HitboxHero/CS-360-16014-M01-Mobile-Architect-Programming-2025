package com.alex.inventori;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.alex.inventori.database.AppDatabase;
import com.alex.inventori.database.InventoryDao;
import com.alex.inventori.database.InventoryItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

// main screen that lists inventory and lets me add and adjust items
public class InventoryActivity extends AppCompatActivity implements OnItemClickListener {

    private AppDatabase db;
    private InventoryDao inventoryDao;
    private RecyclerView inventoryGridView;
    private InventoryAdapter adapter;

    // fabs
    private FloatingActionButton fabAddItem;
    private FloatingActionButton fabSms;

    // toggle state
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "inventori_prefs";
    private static final String PREF_SMS_ALERTS = "sms_alerts_enabled";

    // sms bits
    private static final int REQ_SEND_SMS = 1001;
    private static final int LOW_STOCK_THRESHOLD = 1; // when qty <= this, send alert
    private Runnable pendingSmsAction = null; // action to run after permission is granted

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // db and dao
        db = AppDatabase.getDatabase(this);
        inventoryDao = db.inventoryDao();

        // prefs for toggle
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // recycler setup
        inventoryGridView = findViewById(R.id.inventory_grid_view);
        inventoryGridView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(new ArrayList<>(), this);
        inventoryGridView.setAdapter(adapter);

        // initial data
        loadInventoryItems();

        // add item button
        fabAddItem = findViewById(R.id.fab_add_item);
        fabAddItem.setOnClickListener(v -> {
            // simple dialog to add an item
            AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
            builder.setView(dialogView);

            EditText itemNameEditText = dialogView.findViewById(R.id.edit_text_item_name);
            EditText quantityEditText = dialogView.findViewById(R.id.edit_text_quantity);
            Button saveButton = dialogView.findViewById(R.id.button_save_item);

            AlertDialog dialog = builder.create();

            saveButton.setOnClickListener(btn -> {
                String itemName = itemNameEditText.getText().toString().trim();
                String quantityStr = quantityEditText.getText().toString().trim();

                // basic input guard
                if (itemName.isEmpty() || quantityStr.isEmpty()) {
                    Toast.makeText(InventoryActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int quantity;
                try {
                    quantity = Integer.parseInt(quantityStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(InventoryActivity.this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
                    return;
                }

                InventoryItem newItem = new InventoryItem();
                newItem.itemName = itemName;
                newItem.quantity = quantity;

                // write to db off the main thread
                new Thread(() -> {
                    inventoryDao.insert(newItem);
                    runOnUiThread(() -> {
                        Toast.makeText(InventoryActivity.this, "Item added!", Toast.LENGTH_SHORT).show();
                        loadInventoryItems();
                    });
                }).start();

                dialog.dismiss();
            });

            dialog.show();
        });

        // sms toggle button (bottom-left)
        fabSms = findViewById(R.id.fab_sms);
        updateSmsIcon(); // dim when off

        fabSms.setOnClickListener(v -> {
            boolean enabled = smsAlertsEnabled();
            if (!enabled) {
                // turning on; if permission ok, enable now, else ask first
                if (hasSmsPermission()) {
                    prefs.edit().putBoolean(PREF_SMS_ALERTS, true).apply();
                    Toast.makeText(this, "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                    updateSmsIcon();
                } else {
                    pendingSmsAction = () -> {
                        prefs.edit().putBoolean(PREF_SMS_ALERTS, true).apply();
                        Toast.makeText(this, "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                        updateSmsIcon();
                    };
                    requestSmsPermission();
                }
            } else {
                // turning off
                prefs.edit().putBoolean(PREF_SMS_ALERTS, false).apply();
                Toast.makeText(this, "SMS alerts disabled", Toast.LENGTH_SHORT).show();
                updateSmsIcon();
            }
        });
    }

    // pulls items from db and refreshes the list
    private void loadInventoryItems() {
        new Thread(() -> {
            List<InventoryItem> items = inventoryDao.getAllItems();
            runOnUiThread(() -> adapter.setItems(items));
        }).start();
    }

    // plus button from the adapter
    @Override
    public void onPlusClick(InventoryItem item) {
        item.quantity++;
        new Thread(() -> {
            inventoryDao.update(item);
            runOnUiThread(() -> adapter.notifyDataSetChanged());
        }).start();
    }

    // minus button from the adapter
    @Override
    public void onMinusClick(InventoryItem item) {
        if (item.quantity > 0) {
            item.quantity--;
            new Thread(() -> {
                inventoryDao.update(item);
                runOnUiThread(() -> adapter.notifyDataSetChanged());
            }).start();

            // low stock trigger for sms
            if (item.quantity <= LOW_STOCK_THRESHOLD) {
                trySendLowInventorySms(item);
            }
        }
    }

    /* ===== sms permission, toggle, and sending ===== */

    private boolean smsAlertsEnabled() {
        return prefs != null && prefs.getBoolean(PREF_SMS_ALERTS, false);
    }

    private void updateSmsIcon() {
        // simple visual cue: dim when off
        boolean on = smsAlertsEnabled();
        if (fabSms != null) fabSms.setAlpha(on ? 1f : 0.5f);
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        // quick rationale before the prompt
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable SMS alerts")
                    .setMessage("Sends a text when an item is low. The app works fine without this.")
                    .setPositiveButton("Allow", (d, w) -> ActivityCompat.requestPermissions(
                            this, new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS))
                    .setNegativeButton("Not now", null)
                    .show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
        }
    }

    // for emulator testing: send from one emulator to another (e.g., 5554 -> 5556)
    private String getAlertPhoneNumber() {
        return "5556";
    }

    private void sendLowInventorySmsNow(InventoryItem item) {
        String phone = getAlertPhoneNumber();
        String msg = "Low inventory: " + item.itemName + " (qty " + item.quantity + ")";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void trySendLowInventorySms(InventoryItem item) {
        // respect the toggle
        if (!smsAlertsEnabled()) return;

        if (hasSmsPermission()) {
            sendLowInventorySmsNow(item);
        } else {
            // remember what was about to run, then ask for permission
            pendingSmsAction = () -> sendLowInventorySmsNow(item);
            requestSmsPermission();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                if (pendingSmsAction != null) pendingSmsAction.run();
                pendingSmsAction = null;
            } else {
                // permission denied; keep going without sms
                pendingSmsAction = null;

                boolean permanentlyDenied =
                        !ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS);

                if (permanentlyDenied) {
                    Toast.makeText(this, "SMS permission permanently denied. Enable in Settings if needed.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "SMS permission denied. Running without text alerts.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
