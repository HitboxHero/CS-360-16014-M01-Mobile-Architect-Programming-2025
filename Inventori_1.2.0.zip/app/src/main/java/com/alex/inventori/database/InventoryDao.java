package com.alex.inventori.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface InventoryDao {

    // This method is for adding a new item to the database.
    @Insert
    void insert(InventoryItem item);

    // This method is for changing an existing item.
    @Update
    void update(InventoryItem item);

    // This method is for removing an item from the database.
    @Delete
    void delete(InventoryItem item);

    // This is a custom query to get all items from the "inventory_items" table.
    // It returns a List of all InventoryItem objects.
    @Query("SELECT * FROM inventory_items")
    List<InventoryItem> getAllItems();
}