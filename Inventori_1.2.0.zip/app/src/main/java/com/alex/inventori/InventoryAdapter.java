package com.alex.inventori;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alex.inventori.database.InventoryItem;
import java.util.List;

/**
 * An adapter for displaying a list of inventory items in a RecyclerView.
 * This class handles creating the item views and binding data to them.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // A reference to the list of items to be displayed.
    private List<InventoryItem> inventoryItems;
    // A listener to handle item clicks (e.g., plus/minus buttons).
    private OnItemClickListener listener;

    /**
     * The constructor for the adapter.
     * @param inventoryItems The list of data to display.
     * @param listener The listener for button clicks on each item.
     */
    public InventoryAdapter(List<InventoryItem> inventoryItems, OnItemClickListener listener) {
        this.inventoryItems = inventoryItems;
        this.listener = listener;
    }

    /**
     * Called when a new ViewHolder is created. It inflates the item layout.
     */
    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    /**
     * Binds the data from the list to the views in the ViewHolder.
     * It also sets up click listeners for the buttons.
     */
    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = inventoryItems.get(position);
        holder.itemNameTextView.setText(item.itemName);
        holder.quantityTextView.setText("Quantity: " + item.quantity);

        // Set click listener for the plus button.
        holder.plusButton.setOnClickListener(v -> {
            // Check if a listener exists before calling the method.
            if (listener != null) {
                listener.onPlusClick(item);
            }
        });

        // Set click listener for the minus button.
        holder.minusButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onMinusClick(item);
            }
        });
    }

    /**
     * Returns the total number of items in the data set.
     */
    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    /**
     * Updates the data in the adapter and refreshes the RecyclerView.
     * @param items The new list of items.
     */
    public void setItems(List<InventoryItem> items) {
        this.inventoryItems = items;
        notifyDataSetChanged();
    }

    /**
     * The ViewHolder class holds references to the views for each list item.
     */
    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView;
        TextView quantityTextView;
        ImageView itemImageView;
        ImageButton plusButton;
        ImageButton minusButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.text_view_item_name);
            quantityTextView = itemView.findViewById(R.id.text_view_quantity);
            itemImageView = itemView.findViewById(R.id.item_image);
            plusButton = itemView.findViewById(R.id.button_plus);
            minusButton = itemView.findViewById(R.id.button_minus);
        }
    }


}