package com.alex.inventori.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// This defines the database table for users.
@Entity(tableName = "users")
public class User {

    // A unique ID for each user, automatically generated.
    @PrimaryKey(autoGenerate = true)
    public int id;

    // The username for login.
    public String username;


    public String passwordHash;
}